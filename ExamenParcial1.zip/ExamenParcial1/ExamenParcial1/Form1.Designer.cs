﻿namespace ExamenParcial1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.ingresar = new System.Windows.Forms.Button();
            this.generarElementos = new System.Windows.Forms.Button();
            this.insertarPrimo = new System.Windows.Forms.Button();
            this.leerElemento = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cola Inicial";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 58);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(164, 264);
            this.listBox1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(229, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Cola Final";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(232, 58);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(164, 264);
            this.listBox2.TabIndex = 3;
            // 
            // ingresar
            // 
            this.ingresar.Location = new System.Drawing.Point(12, 345);
            this.ingresar.Name = "ingresar";
            this.ingresar.Size = new System.Drawing.Size(101, 23);
            this.ingresar.TabIndex = 4;
            this.ingresar.Text = "Ingresar Elemento";
            this.ingresar.UseVisualStyleBackColor = true;
            this.ingresar.Click += new System.EventHandler(this.ingresar_Click);
            // 
            // generarElementos
            // 
            this.generarElementos.Location = new System.Drawing.Point(12, 374);
            this.generarElementos.Name = "generarElementos";
            this.generarElementos.Size = new System.Drawing.Size(101, 23);
            this.generarElementos.TabIndex = 5;
            this.generarElementos.Text = "Generar";
            this.generarElementos.UseVisualStyleBackColor = true;
            this.generarElementos.Click += new System.EventHandler(this.generarElementos_Click);
            // 
            // insertarPrimo
            // 
            this.insertarPrimo.Location = new System.Drawing.Point(12, 403);
            this.insertarPrimo.Name = "insertarPrimo";
            this.insertarPrimo.Size = new System.Drawing.Size(101, 23);
            this.insertarPrimo.TabIndex = 6;
            this.insertarPrimo.Text = "Insertar Primo";
            this.insertarPrimo.UseVisualStyleBackColor = true;
            this.insertarPrimo.Click += new System.EventHandler(this.insertarPrimo_Click);
            // 
            // leerElemento
            // 
            this.leerElemento.Location = new System.Drawing.Point(119, 347);
            this.leerElemento.Name = "leerElemento";
            this.leerElemento.Size = new System.Drawing.Size(100, 20);
            this.leerElemento.TabIndex = 7;
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(241, 347);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(121, 97);
            this.listView1.TabIndex = 8;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 514);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.leerElemento);
            this.Controls.Add(this.insertarPrimo);
            this.Controls.Add(this.generarElementos);
            this.Controls.Add(this.ingresar);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Examen Parcial";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button ingresar;
        private System.Windows.Forms.Button generarElementos;
        private System.Windows.Forms.Button insertarPrimo;
        private System.Windows.Forms.TextBox leerElemento;
        private System.Windows.Forms.ListView listView1;
    }
}

