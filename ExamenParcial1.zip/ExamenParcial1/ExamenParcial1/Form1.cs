﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EstrcuturasDinamicas;

namespace ExamenParcial1
{
    public partial class Form1 : Form
    {
        //Lista con disciplina de cola
        MyLinkedList<int> myQueue = new MyLinkedList<int>();
        
        public bool esPrimo(int num)
        {
            int cont = 1;
            for (int i = 2; i < num + 1; i++)
            {
                if (num % i == 0)
                {
                    cont++;
                }
            }

            if (cont == 2)
            {
                return true;
            }
            else
            {
                return false; 
            }
        }
        public void insertarPrimoQ()
        {
            Node<int> auxiliar = myQueue.head;
            Node<int> aux2 = auxiliar;

            while (aux2 != null)
            {
                while (esPrimo(int.Parse(auxiliar.getElement().ToString())) != true && auxiliar.getNext() != null)
                {
                    auxiliar = auxiliar.getNext();                    
                }

                    if (auxiliar.getNext() != null)
                    {
                        aux2 = auxiliar.getNext();
                        myQueue.addElement(auxiliar.getElement(), (auxiliar.getElement() * auxiliar.getNext().getElement()));
                        auxiliar = aux2;
                    }
                    else
                    {
                        myQueue.addElement(auxiliar.getElement(), 0);
                        aux2 = auxiliar.getNext();
                    }
                            
            }
        }    

        public static bool parsed(string _string)
        {
            int numValue;
            return int.TryParse(_string, out numValue);
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void ingresar_Click(object sender, EventArgs e)
        {
            if (parsed(leerElemento.Text))
            {
                myQueue.addLast(int.Parse(leerElemento.Text));
                listBox1.Items.Add(leerElemento.Text);
                leerElemento.Clear();
            }
            else
            {
                MessageBox.Show("NO PUEDE INSERTARSE EL ELEMENTO EN LA COLA.");
                leerElemento.Clear();
            }

        }

        private void generarElementos_Click(object sender, EventArgs e)
        {
            Random generador = new Random();
            int num = generador.Next(1, 101);
            for (int i = 0; i < 100; i++)
            {
                myQueue.addLast(num);
                listBox1.Items.Add(num);
                num = generador.Next(1, 101);
            }      
            
        }

        private void insertarPrimo_Click(object sender, EventArgs e)
        {
            if (myQueue.isEmpty())
            {
                MessageBox.Show("LA COLA ESTÁ VACÍA.");
            }
            else
            {
                insertarPrimoQ();
                int size = myQueue.size();
                for (int i = 0; i < size; i++)
                {
                    listBox2.Items.Add(myQueue.removeFirst());
                }
            }
        }
    }
}
