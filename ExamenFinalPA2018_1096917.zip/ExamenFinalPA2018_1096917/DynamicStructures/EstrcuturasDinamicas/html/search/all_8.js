var searchData=
[
  ['purge',['purge',['../class_estrcuturas_dinamicas_1_1_my_linked_list.html#a7c05c0bb0d58e004735ff7c70a7b42f4',1,'EstrcuturasDinamicas::MyLinkedList']]]
];
