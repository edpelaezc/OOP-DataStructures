var searchData=
[
  ['getelement',['getElement',['../class_estrcuturas_dinamicas_1_1_node.html#a98a8fbb4ded20ee02d91d2982c094dc2',1,'EstrcuturasDinamicas::Node']]],
  ['getnext',['getNext',['../class_estrcuturas_dinamicas_1_1_node.html#a93966d358beb06f39a4b6648fda1d04c',1,'EstrcuturasDinamicas::Node']]]
];
