var searchData=
[
  ['node',['Node',['../class_estrcuturas_dinamicas_1_1_node.html',1,'EstrcuturasDinamicas.Node&lt; T &gt;'],['../class_estrcuturas_dinamicas_1_1_node.html#aadac6302fd412298209a5e066beb127f',1,'EstrcuturasDinamicas.Node.Node()']]]
];
