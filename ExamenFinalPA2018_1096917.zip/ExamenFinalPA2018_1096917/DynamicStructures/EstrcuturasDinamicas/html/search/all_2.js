var searchData=
[
  ['first',['first',['../class_estrcuturas_dinamicas_1_1_my_linked_list.html#a6d0d64bd7ee90f7025204a70ac15394e',1,'EstrcuturasDinamicas::MyLinkedList']]]
];
