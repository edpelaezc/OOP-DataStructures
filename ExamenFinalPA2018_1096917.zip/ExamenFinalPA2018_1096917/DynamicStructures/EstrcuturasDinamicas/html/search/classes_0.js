var searchData=
[
  ['linkedqueue',['LinkedQueue',['../class_estrcuturas_dinamicas_1_1_linked_queue.html',1,'EstrcuturasDinamicas']]],
  ['linkedstack',['LinkedStack',['../class_estrcuturas_dinamicas_1_1_linked_stack.html',1,'EstrcuturasDinamicas']]]
];
