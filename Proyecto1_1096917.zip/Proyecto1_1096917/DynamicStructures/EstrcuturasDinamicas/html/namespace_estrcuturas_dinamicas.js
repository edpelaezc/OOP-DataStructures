var namespace_estrcuturas_dinamicas =
[
    [ "LinkedQueue", "class_estrcuturas_dinamicas_1_1_linked_queue.html", "class_estrcuturas_dinamicas_1_1_linked_queue" ],
    [ "LinkedStack", "class_estrcuturas_dinamicas_1_1_linked_stack.html", "class_estrcuturas_dinamicas_1_1_linked_stack" ],
    [ "MyLinkedList", "class_estrcuturas_dinamicas_1_1_my_linked_list.html", "class_estrcuturas_dinamicas_1_1_my_linked_list" ],
    [ "Node", "class_estrcuturas_dinamicas_1_1_node.html", "class_estrcuturas_dinamicas_1_1_node" ],
    [ "Queue", "class_estrcuturas_dinamicas_1_1_queue.html", "class_estrcuturas_dinamicas_1_1_queue" ],
    [ "Stack", "class_estrcuturas_dinamicas_1_1_stack.html", "class_estrcuturas_dinamicas_1_1_stack" ]
];