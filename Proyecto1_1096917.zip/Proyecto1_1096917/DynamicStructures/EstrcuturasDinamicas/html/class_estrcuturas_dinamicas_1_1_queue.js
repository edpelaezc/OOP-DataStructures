var class_estrcuturas_dinamicas_1_1_queue =
[
    [ "dequeue", "class_estrcuturas_dinamicas_1_1_queue.html#aad28514a9e86b171a554c46ecda2f82d", null ],
    [ "enqueue", "class_estrcuturas_dinamicas_1_1_queue.html#a2f90cab8f6047bc35a4df8e1b4ffb084", null ],
    [ "front", "class_estrcuturas_dinamicas_1_1_queue.html#a7eb87ece98a9cdc25ab8adf671f23eec", null ],
    [ "isEmpty", "class_estrcuturas_dinamicas_1_1_queue.html#a65fd96464d5cbc47f4e5b9fafe771439", null ],
    [ "purge", "class_estrcuturas_dinamicas_1_1_queue.html#a42673181d5230fa7cddc30c9b3372b13", null ],
    [ "queueToArray", "class_estrcuturas_dinamicas_1_1_queue.html#a5aeb3c6425228f79993ae5a6117f6d4b", null ],
    [ "size", "class_estrcuturas_dinamicas_1_1_queue.html#a29404de883d99d3f90db573181892efc", null ]
];