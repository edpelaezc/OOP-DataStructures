var searchData=
[
  ['mylinkedlist',['MyLinkedList',['../class_estrcuturas_dinamicas_1_1_my_linked_list.html',1,'EstrcuturasDinamicas.MyLinkedList&lt; T &gt;'],['../class_estrcuturas_dinamicas_1_1_my_linked_list.html#a72b7dc72745511378a8847937c8325f6',1,'EstrcuturasDinamicas.MyLinkedList.MyLinkedList()']]]
];
