var searchData=
[
  ['isempty',['isEmpty',['../class_estrcuturas_dinamicas_1_1_my_linked_list.html#a99fccf5f309b105f3671e0e89188c472',1,'EstrcuturasDinamicas::MyLinkedList']]]
];
