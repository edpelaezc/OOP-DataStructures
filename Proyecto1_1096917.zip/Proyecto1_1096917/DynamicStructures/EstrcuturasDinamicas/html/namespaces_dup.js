var namespaces_dup =
[
    [ "EstrcuturasDinamicas", "namespace_estrcuturas_dinamicas.html", null ]
];