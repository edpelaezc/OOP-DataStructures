var hierarchy =
[
    [ "EstrcuturasDinamicas.MyLinkedList< T >", "class_estrcuturas_dinamicas_1_1_my_linked_list.html", null ],
    [ "EstrcuturasDinamicas.Node< T >", "class_estrcuturas_dinamicas_1_1_node.html", null ],
    [ "EstrcuturasDinamicas.Queue< T >", "class_estrcuturas_dinamicas_1_1_queue.html", [
      [ "EstrcuturasDinamicas.LinkedQueue< T >", "class_estrcuturas_dinamicas_1_1_linked_queue.html", null ]
    ] ],
    [ "EstrcuturasDinamicas.Stack< T >", "class_estrcuturas_dinamicas_1_1_stack.html", [
      [ "EstrcuturasDinamicas.LinkedStack< T >", "class_estrcuturas_dinamicas_1_1_linked_stack.html", null ]
    ] ]
];