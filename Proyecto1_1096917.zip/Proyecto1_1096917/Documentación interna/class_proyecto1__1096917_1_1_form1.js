var class_proyecto1__1096917_1_1_form1 =
[
    [ "Form1", "class_proyecto1__1096917_1_1_form1.html#addb0481ec860e48f76b262f4ff26b6ec", null ],
    [ "close", "class_proyecto1__1096917_1_1_form1.html#a0bdf3e74bcdc4dbc9dd959f791668d42", null ],
    [ "Dispose", "class_proyecto1__1096917_1_1_form1.html#acc2460d7f1237443a701fe741cbc183d", null ]
];