var class_proyecto1__1096917_1_1_message =
[
    [ "Message", "class_proyecto1__1096917_1_1_message.html#a12cecdedb00d6872604ed24e1b507ee1", null ],
    [ "getEmail", "class_proyecto1__1096917_1_1_message.html#a0fb950348ba55b507661e51d587f1790", null ],
    [ "getHour", "class_proyecto1__1096917_1_1_message.html#aff4aef6ba51891502e1845915af12918", null ],
    [ "getSend", "class_proyecto1__1096917_1_1_message.html#abe6b483413463a54218f63af8e66dd51", null ],
    [ "getStatus", "class_proyecto1__1096917_1_1_message.html#a4a130fa96a6850303fd1b994665d51a4", null ],
    [ "getText", "class_proyecto1__1096917_1_1_message.html#a6a9c0e0b0a03d3c5114e31f2cb7d153f", null ],
    [ "setEmail", "class_proyecto1__1096917_1_1_message.html#ad022d2a23bdcaa1fdaed0a77b01c4e86", null ],
    [ "setHour", "class_proyecto1__1096917_1_1_message.html#ac82c347541eb8b4ce48c0e606873a113", null ],
    [ "setSend", "class_proyecto1__1096917_1_1_message.html#a852c238aae9dcc0c31177ab06b91f64c", null ],
    [ "setStatus", "class_proyecto1__1096917_1_1_message.html#a621ef755eee36b359f109ce7164b9289", null ],
    [ "setText", "class_proyecto1__1096917_1_1_message.html#a8a0e53bb33cf7b8f5a9d163e43811999", null ],
    [ "toString", "class_proyecto1__1096917_1_1_message.html#a9f4885c15c1edaa550f1b19bc17a1b1a", null ]
];