var class_proyecto1__1096917_1_1_main_page =
[
    [ "MainPage", "class_proyecto1__1096917_1_1_main_page.html#a09fc46aaf6cb59984d39161b164a4dc7", null ],
    [ "Dispose", "class_proyecto1__1096917_1_1_main_page.html#a6dcba2644a4939b0dde2c227e96710b0", null ]
];