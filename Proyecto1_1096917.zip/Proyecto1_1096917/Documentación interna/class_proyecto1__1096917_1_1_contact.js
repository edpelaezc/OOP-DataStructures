var class_proyecto1__1096917_1_1_contact =
[
    [ "Contact", "class_proyecto1__1096917_1_1_contact.html#a83ff88131cf40e76a7897a1fadcaa679", null ],
    [ "getAge", "class_proyecto1__1096917_1_1_contact.html#aa2c6686b8fea9a2ee250282aaaaca4e8", null ],
    [ "getBirthDate", "class_proyecto1__1096917_1_1_contact.html#a69830372183b3b2c9ea29fddb26448ca", null ],
    [ "getEmail", "class_proyecto1__1096917_1_1_contact.html#aafbea71ed93e81b92e2946e94432f4b4", null ],
    [ "getLastName", "class_proyecto1__1096917_1_1_contact.html#a391606fb83c64b79fb1e485bf252b3a5", null ],
    [ "getName", "class_proyecto1__1096917_1_1_contact.html#a2ccfe34c7e28c6953d70260d00ce9289", null ],
    [ "getStatus", "class_proyecto1__1096917_1_1_contact.html#adcf2884f5e6a92bbce92b3e87ba713cd", null ],
    [ "setAge", "class_proyecto1__1096917_1_1_contact.html#ac4ff19459ba600290ef42009e8618044", null ],
    [ "setBirthDate", "class_proyecto1__1096917_1_1_contact.html#a88e5a65983010ae1772338a55dc60bef", null ],
    [ "setEmail", "class_proyecto1__1096917_1_1_contact.html#a4633112f241b8aeb6469f3d63ad286a1", null ],
    [ "setLastName", "class_proyecto1__1096917_1_1_contact.html#a8e874088b5626c54691a2e09782d6425", null ],
    [ "setName", "class_proyecto1__1096917_1_1_contact.html#a3e594e72637ba39fc36b2e046642cee4", null ],
    [ "setStatus", "class_proyecto1__1096917_1_1_contact.html#a3a039163a72bef3ff198150e62b305ba", null ],
    [ "toString", "class_proyecto1__1096917_1_1_contact.html#a7af16c68b374d08887105c583031c23a", null ]
];