var namespace_proyecto1__1096917 =
[
    [ "Contact", "class_proyecto1__1096917_1_1_contact.html", "class_proyecto1__1096917_1_1_contact" ],
    [ "Form1", "class_proyecto1__1096917_1_1_form1.html", "class_proyecto1__1096917_1_1_form1" ],
    [ "Loading", "class_proyecto1__1096917_1_1_loading.html", "class_proyecto1__1096917_1_1_loading" ],
    [ "MainPage", "class_proyecto1__1096917_1_1_main_page.html", "class_proyecto1__1096917_1_1_main_page" ],
    [ "Message", "class_proyecto1__1096917_1_1_message.html", "class_proyecto1__1096917_1_1_message" ],
    [ "News", "class_proyecto1__1096917_1_1_news.html", "class_proyecto1__1096917_1_1_news" ]
];