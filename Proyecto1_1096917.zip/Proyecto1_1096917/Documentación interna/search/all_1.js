var searchData=
[
  ['dispose',['Dispose',['../class_proyecto1__1096917_1_1_form1.html#acc2460d7f1237443a701fe741cbc183d',1,'Proyecto1_1096917.Form1.Dispose()'],['../class_proyecto1__1096917_1_1_loading.html#a377074dd9fbc481999dd330adf7f69a0',1,'Proyecto1_1096917.Loading.Dispose()'],['../class_proyecto1__1096917_1_1_main_page.html#a6dcba2644a4939b0dde2c227e96710b0',1,'Proyecto1_1096917.MainPage.Dispose()']]]
];
