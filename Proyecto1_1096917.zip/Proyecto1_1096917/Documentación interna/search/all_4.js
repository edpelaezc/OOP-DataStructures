var searchData=
[
  ['mainpage',['MainPage',['../class_proyecto1__1096917_1_1_main_page.html',1,'Proyecto1_1096917.MainPage'],['../class_proyecto1__1096917_1_1_main_page.html#a09fc46aaf6cb59984d39161b164a4dc7',1,'Proyecto1_1096917.MainPage.MainPage()']]],
  ['message',['Message',['../class_proyecto1__1096917_1_1_message.html',1,'Proyecto1_1096917.Message'],['../class_proyecto1__1096917_1_1_message.html#a12cecdedb00d6872604ed24e1b507ee1',1,'Proyecto1_1096917.Message.Message()']]]
];
