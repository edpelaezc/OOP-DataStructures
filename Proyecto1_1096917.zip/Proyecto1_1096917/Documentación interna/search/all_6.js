var searchData=
[
  ['properties',['Properties',['../namespace_proyecto1__1096917_1_1_properties.html',1,'Proyecto1_1096917']]],
  ['proyecto1_5f1096917',['Proyecto1_1096917',['../namespace_proyecto1__1096917.html',1,'']]]
];
