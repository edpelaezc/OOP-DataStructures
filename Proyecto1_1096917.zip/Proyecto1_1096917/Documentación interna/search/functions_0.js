var searchData=
[
  ['close',['close',['../class_proyecto1__1096917_1_1_form1.html#a0bdf3e74bcdc4dbc9dd959f791668d42',1,'Proyecto1_1096917::Form1']]],
  ['contact',['Contact',['../class_proyecto1__1096917_1_1_contact.html#a83ff88131cf40e76a7897a1fadcaa679',1,'Proyecto1_1096917::Contact']]]
];
