var searchData=
[
  ['mainpage',['MainPage',['../class_proyecto1__1096917_1_1_main_page.html',1,'Proyecto1_1096917']]],
  ['message',['Message',['../class_proyecto1__1096917_1_1_message.html',1,'Proyecto1_1096917']]]
];
