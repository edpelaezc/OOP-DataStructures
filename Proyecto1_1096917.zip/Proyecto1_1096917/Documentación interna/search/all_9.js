var searchData=
[
  ['validate',['validate',['../class_proyecto1__1096917_1_1_form1.html#a2c873349728e55828bbf9f2f1d3e2498',1,'Proyecto1_1096917::Form1']]]
];
