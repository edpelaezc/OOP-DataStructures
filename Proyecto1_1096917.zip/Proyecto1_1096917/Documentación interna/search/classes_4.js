var searchData=
[
  ['news',['News',['../class_proyecto1__1096917_1_1_news.html',1,'Proyecto1_1096917']]]
];
