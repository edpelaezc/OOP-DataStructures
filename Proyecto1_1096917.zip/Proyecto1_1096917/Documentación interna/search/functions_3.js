var searchData=
[
  ['news',['News',['../class_proyecto1__1096917_1_1_news.html#a137a8d0b1d8d226db2895518c7cba0a6',1,'Proyecto1_1096917::News']]]
];
