var searchData=
[
  ['resizeimage',['resizeImage',['../class_proyecto1__1096917_1_1_main_page.html#ac6f45a16f97ec2509701d3fafe7e4dda',1,'Proyecto1_1096917::MainPage']]]
];
