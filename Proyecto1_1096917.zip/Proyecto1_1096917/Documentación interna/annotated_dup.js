var annotated_dup =
[
    [ "Proyecto1_1096917", "namespace_proyecto1__1096917.html", "namespace_proyecto1__1096917" ]
];