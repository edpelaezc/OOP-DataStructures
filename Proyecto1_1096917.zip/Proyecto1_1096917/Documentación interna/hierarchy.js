var hierarchy =
[
    [ "Proyecto1_1096917.Contact", "class_proyecto1__1096917_1_1_contact.html", null ],
    [ "Form", null, [
      [ "Proyecto1_1096917.Form1", "class_proyecto1__1096917_1_1_form1.html", null ],
      [ "Proyecto1_1096917.Loading", "class_proyecto1__1096917_1_1_loading.html", null ],
      [ "Proyecto1_1096917.MainPage", "class_proyecto1__1096917_1_1_main_page.html", null ]
    ] ],
    [ "Proyecto1_1096917.Message", "class_proyecto1__1096917_1_1_message.html", null ],
    [ "Proyecto1_1096917.News", "class_proyecto1__1096917_1_1_news.html", null ]
];