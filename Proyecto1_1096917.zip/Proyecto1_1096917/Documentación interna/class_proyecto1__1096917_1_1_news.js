var class_proyecto1__1096917_1_1_news =
[
    [ "News", "class_proyecto1__1096917_1_1_news.html#a137a8d0b1d8d226db2895518c7cba0a6", null ],
    [ "getEmail", "class_proyecto1__1096917_1_1_news.html#a336c0d1976a3b83c7d2b7594cb7ba53b", null ],
    [ "getPath", "class_proyecto1__1096917_1_1_news.html#ad698885a7e98e6becf54d4a3c322e38b", null ],
    [ "getText", "class_proyecto1__1096917_1_1_news.html#a10751e00e06d93c0e93c73f68877a240", null ],
    [ "getType", "class_proyecto1__1096917_1_1_news.html#a9a87c0f6c4245b3ef056c2d01e5dba86", null ],
    [ "setEmail", "class_proyecto1__1096917_1_1_news.html#a915251303797bbb3a893411085c2a1c1", null ],
    [ "setPath", "class_proyecto1__1096917_1_1_news.html#abcbcb5da2840dadc8e60e6eeccebd286", null ],
    [ "setText", "class_proyecto1__1096917_1_1_news.html#aa794c357aa54179cacd2c42e8421eeac", null ],
    [ "setType", "class_proyecto1__1096917_1_1_news.html#afb7d48a37581ac43e007b9e572ecb749", null ],
    [ "toString", "class_proyecto1__1096917_1_1_news.html#a9eca1fd7f72feb28f6c518a21d7486fd", null ]
];