var searchData=
[
  ['stack',['Stack',['../class_estrcuturas_dinamicas_1_1_stack.html',1,'EstrcuturasDinamicas']]]
];
