var class_estrcuturas_dinamicas_1_1_node =
[
    [ "Node", "class_estrcuturas_dinamicas_1_1_node.html#aadac6302fd412298209a5e066beb127f", null ],
    [ "getElement", "class_estrcuturas_dinamicas_1_1_node.html#a98a8fbb4ded20ee02d91d2982c094dc2", null ],
    [ "getNext", "class_estrcuturas_dinamicas_1_1_node.html#a93966d358beb06f39a4b6648fda1d04c", null ],
    [ "setNext", "class_estrcuturas_dinamicas_1_1_node.html#a4b40879d12a8659a42648db55b9fae34", null ]
];